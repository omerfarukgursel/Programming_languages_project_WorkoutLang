# WorkoutLang — D2 Implementation (Part 2)

A domain-specific language for fitness programming.
Student: 210104004053 | CSE 341 | Gebze Technical University | Spring 2026

## Build

```bash
make
```

Requires: `gcc` with C11 support. Zero warnings under `-Wall -Wextra -std=c11`.

## Run

```bash
# Parse + type check + execute (default)
./workoutlang <file.wl>

# Parse only, dump AST
./workoutlang --dump-ast <file.wl>

# Parse + type check only (no execution)
./workoutlang --type-check <file.wl>
```

## Source Files

| File | Description |
|------|-------------|
| `lexer.c / .h` | Tokeniser — recognises DURATION_LIT, WEIGHT_LIT, all keywords |
| `parser.c / .h` | Recursive descent parser — produces AST, reports errors with line numbers |
| `ast.c / .h` | AST node definitions (tagged union) and printer |
| `symbol_table.c / .h` | Environment chain — static scoping via linked list of scope frames |
| `type_checker.c / .h` | Two-pass type checker — strong typing, no coercion, name equivalence |
| `interpreter.c / .h` | Tree-walking interpreter — call-by-value, short-circuit eval, runtime errors |
| `main.c` | Entry point — pipeline: lex → parse → type-check → interpret |

## Test Programs

```bash
# Valid programs (parse + type check + execute)
./workoutlang tests/valid1.wl
./workoutlang tests/valid2.wl
./workoutlang tests/valid3.wl

# Parser error programs (reject with line numbers)
./workoutlang tests/error1.wl
./workoutlang tests/error2.wl
./workoutlang tests/error3.wl
./workoutlang tests/error4.wl
./workoutlang tests/error5.wl

# Type error programs
./workoutlang tests/type_error1.wl   # bool variable = int
./workoutlang tests/type_error2.wl   # division by zero (runtime)
./workoutlang tests/type_error3.wl   # if condition not bool
```

## Pipeline

```
source.wl → Lexer → Token stream
                  → Parser → AST
                           → Type Checker → symbol table check
                                          → Interpreter → stdout
```

## Design Decisions (see D1 for full rationale)

- **Static scoping**: name resolution walks environment chain from innermost to outermost
- **Strong typing**: no implicit coercion between any of the 5 types
- **Stack-dynamic lifetime**: all local variables destroyed on block exit
- **Call-by-value**: arguments evaluated before scope_enter, bound as copies
- **Short-circuit**: `&&` and `||` use lazy evaluation
- **Assignment is a statement**: cannot appear inside expressions
