routine badCondition {
    int volume = 25
    if volume {
        print "should not reach here"
    }
}
