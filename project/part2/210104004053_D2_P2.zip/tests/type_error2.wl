func divide(num: int, den: int) : int {
    return num / den
}
routine test {
    int result = divide(10, 0)
    print result
}
