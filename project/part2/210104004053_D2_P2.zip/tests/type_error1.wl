routine badTypes {
    int volume = 5
    bool result = volume
}
