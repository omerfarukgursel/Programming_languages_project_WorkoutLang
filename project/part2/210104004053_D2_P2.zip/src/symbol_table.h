#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

/*
 * symbol_table.h — WorkoutLang Symbol Table
 *
 * Implements static (lexical) scoping via an environment chain:
 * a linked list of scope frames, each holding a fixed-size array
 * of symbol entries. scope_lookup() walks innermost → outermost,
 * matching the static scoping rule declared in D1 §4.6.
 *
 * Scope levels (D1 §4.6):
 *   SCOPE_GLOBAL   — workout / routine / func declarations
 *   SCOPE_FUNCTION — parameters and local variables
 *   SCOPE_BLOCK    — if / while / repeat body variables
 */

#include <stdint.h>

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

#define SCOPE_MAX_ENTRIES 64   /* max symbols per frame               */
#define SYMBOL_NAME_MAX   64   /* max identifier length + NUL         */

/* ------------------------------------------------------------------ */
/* Types  (D1 §4.5)                                                    */
/* ------------------------------------------------------------------ */

typedef enum {
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_BOOL,
    TYPE_DURATION,   /* stored internally as int32_t seconds          */
    TYPE_WEIGHT,     /* stored internally as double kilograms         */
    TYPE_DAY         /* record: single field setCount (int)           */
} WL_Type;

/* ------------------------------------------------------------------ */
/* Value union — no heap allocation for values (D1 §4.6)              */
/* ------------------------------------------------------------------ */

typedef struct {
    int32_t set_count;   /* Day.setCount — the only user-visible field */
} DayValue;

typedef union {
    int32_t  as_int;       /* TYPE_INT                                */
    double   as_float;     /* TYPE_FLOAT                              */
    int      as_bool;      /* TYPE_BOOL:  1 = true, 0 = false        */
    int32_t  as_duration;  /* TYPE_DURATION: seconds                  */
    double   as_weight;    /* TYPE_WEIGHT: kilograms                  */
    DayValue as_day;       /* TYPE_DAY                                */
} WL_Value;

/* ------------------------------------------------------------------ */
/* Symbol entry                                                        */
/* ------------------------------------------------------------------ */

typedef struct {
    char     name[SYMBOL_NAME_MAX];
    WL_Type  type;
    WL_Value value;
    int      is_defined;   /* 0 = slot unused                        */
    int      is_mutable;   /* 0 = read-only (e.g. Day.setCount)      */
} Symbol;

/* ------------------------------------------------------------------ */
/* Scope level tag                                                     */
/* ------------------------------------------------------------------ */

typedef enum {
    SCOPE_GLOBAL,
    SCOPE_FUNCTION,
    SCOPE_BLOCK
} ScopeLevel;

/* ------------------------------------------------------------------ */
/* Scope frame — one node in the environment chain                    */
/* ------------------------------------------------------------------ */

typedef struct ScopeFrame {
    ScopeLevel        level;
    Symbol            entries[SCOPE_MAX_ENTRIES];
    int               count;          /* number of used slots         */
    struct ScopeFrame *enclosing;     /* next frame outward (static)  */
} ScopeFrame;

/* ------------------------------------------------------------------ */
/* Symbol table handle                                                 */
/* ------------------------------------------------------------------ */

typedef struct {
    ScopeFrame *top;   /* innermost (current) frame                   */
} SymbolTable;

/* ------------------------------------------------------------------ */
/* Result codes                                                        */
/* ------------------------------------------------------------------ */

typedef enum {
    SYM_OK,
    SYM_NOT_FOUND,        /* scope_lookup: name not in any frame      */
    SYM_ALREADY_DEFINED,  /* scope_define: name already in this frame */
    SYM_FRAME_FULL,       /* scope_define: current frame is full      */
    SYM_NO_SCOPE,         /* operation with no open scope frame       */
    SYM_IMMUTABLE,        /* attempted write to read-only symbol      */
    SYM_NAME_TOO_LONG     /* identifier exceeds SYMBOL_NAME_MAX-1     */
} SymResult;

/* ------------------------------------------------------------------ */
/* API                                                                 */
/* ------------------------------------------------------------------ */

/*
 * sym_init — initialise a SymbolTable.
 * Must be called before any other operation.
 */
void sym_init(SymbolTable *st);

/*
 * scope_enter — push a new scope frame onto the chain.
 * Returns SYM_OK, or SYM_NO_SCOPE if st is NULL.
 *
 * Memory: frames are allocated with malloc; the table owns them.
 * Call scope_exit() to free.
 */
SymResult scope_enter(SymbolTable *st, ScopeLevel level);

/*
 * scope_exit — pop and free the innermost scope frame.
 * All symbols defined in that frame are destroyed.
 * Returns SYM_NO_SCOPE if there is no open frame.
 */
SymResult scope_exit(SymbolTable *st);

/*
 * scope_define — add a symbol to the CURRENT (innermost) frame only.
 *
 * Enforces D1 §4.6 assign_stmt rule: names of workout/routine/func
 * declarations are tracked as is_mutable=0 at global scope.
 *
 * Returns:
 *   SYM_OK              — symbol added
 *   SYM_ALREADY_DEFINED — name already exists in this frame
 *   SYM_FRAME_FULL      — frame has no free slots
 *   SYM_NO_SCOPE        — no frame is open
 *   SYM_NAME_TOO_LONG   — name exceeds SYMBOL_NAME_MAX-1 chars
 */
SymResult scope_define(SymbolTable *st,
                       const char  *name,
                       WL_Type      type,
                       WL_Value     value,
                       int          is_mutable);

/*
 * scope_lookup — search for name from innermost frame outward.
 *
 * If found, writes a pointer to the Symbol into *out (may be NULL
 * if the caller only wants the result code).
 *
 * Returns:
 *   SYM_OK        — found; *out points to the Symbol
 *   SYM_NOT_FOUND — name not in any frame
 *   SYM_NO_SCOPE  — no frame is open
 */
SymResult scope_lookup(SymbolTable *st,
                       const char  *name,
                       Symbol     **out);

/*
 * scope_assign — update the value of an existing mutable symbol.
 * Walks the chain like scope_lookup, then writes the new value.
 *
 * Returns:
 *   SYM_OK        — value updated
 *   SYM_NOT_FOUND — name not found in any frame
 *   SYM_IMMUTABLE — symbol exists but is read-only
 *   SYM_NO_SCOPE  — no frame is open
 */
SymResult scope_assign(SymbolTable *st,
                       const char  *name,
                       WL_Value     new_value);

/*
 * sym_type_name — return a human-readable string for a WL_Type.
 * Useful for error messages.
 */
const char *sym_type_name(WL_Type type);

/*
 * sym_result_str — return a human-readable string for a SymResult.
 */
const char *sym_result_str(SymResult r);

/*
 * sym_dump — print all frames and their contents to stderr.
 * Intended for debugging; not needed in production.
 */
void sym_dump(const SymbolTable *st);

#endif /* SYMBOL_TABLE_H */
