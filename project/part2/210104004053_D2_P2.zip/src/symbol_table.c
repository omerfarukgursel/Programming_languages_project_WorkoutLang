/*
 * symbol_table.c — WorkoutLang Symbol Table Implementation
 *
 * Environment chain: a linked list of ScopeFrame nodes.
 * st->top always points to the innermost (current) frame.
 * Each frame's ->enclosing pointer leads to the next frame outward.
 *
 * scope_lookup() follows this chain from top toward NULL, which
 * is the direct implementation of static (lexical) scoping as
 * described in D1 §4.6 and Sebesta §5.4.
 *
 * All frame nodes are heap-allocated via malloc/free; no other
 * heap allocation occurs (values are stored inline in a union).
 */

#include "symbol_table.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/* Internal helpers                                                    */
/* ------------------------------------------------------------------ */

/*
 * frame_find — linear search within a single frame.
 * Returns pointer to the matching Symbol, or NULL if not found.
 * Does NOT walk the enclosing chain — that is scope_lookup's job.
 */
static Symbol *frame_find(ScopeFrame *frame, const char *name)
{
    for (int i = 0; i < frame->count; i++) {
        if (frame->entries[i].is_defined &&
            strncmp(frame->entries[i].name, name, SYMBOL_NAME_MAX) == 0) {
            return &frame->entries[i];
        }
    }
    return NULL;
}

/* ------------------------------------------------------------------ */
/* sym_init                                                            */
/* ------------------------------------------------------------------ */

void sym_init(SymbolTable *st)
{
    if (st == NULL) return;
    st->top = NULL;
}

/* ------------------------------------------------------------------ */
/* scope_enter                                                         */
/* ------------------------------------------------------------------ */

SymResult scope_enter(SymbolTable *st, ScopeLevel level)
{
    if (st == NULL) return SYM_NO_SCOPE;

    ScopeFrame *frame = (ScopeFrame *)malloc(sizeof(ScopeFrame));
    if (frame == NULL) {
        /* malloc failure: treat as frame-full for caller's purposes  */
        return SYM_FRAME_FULL;
    }

    /* Zero the entries array so is_defined is 0 for every slot.     */
    memset(frame->entries, 0, sizeof(frame->entries));
    frame->level     = level;
    frame->count     = 0;
    frame->enclosing = st->top;   /* link outward to previous top    */
    st->top          = frame;     /* new frame becomes innermost      */

    return SYM_OK;
}

/* ------------------------------------------------------------------ */
/* scope_exit                                                          */
/* ------------------------------------------------------------------ */

SymResult scope_exit(SymbolTable *st)
{
    if (st == NULL || st->top == NULL) return SYM_NO_SCOPE;

    ScopeFrame *dying = st->top;
    st->top = dying->enclosing;   /* restore previous innermost frame */
    free(dying);

    return SYM_OK;
}

/* ------------------------------------------------------------------ */
/* scope_define                                                        */
/* ------------------------------------------------------------------ */

SymResult scope_define(SymbolTable *st,
                       const char  *name,
                       WL_Type      type,
                       WL_Value     value,
                       int          is_mutable)
{
    if (st == NULL || st->top == NULL) return SYM_NO_SCOPE;
    if (name == NULL)                  return SYM_NOT_FOUND;

    /* Validate name length before touching any frame.
     * Avoid strnlen (POSIX, not C11); scan manually up to the limit. */
    {
        size_t i = 0;
        while (i < SYMBOL_NAME_MAX && name[i] != '\0') i++;
        if (i >= SYMBOL_NAME_MAX) return SYM_NAME_TOO_LONG;
    }

    ScopeFrame *frame = st->top;

    /* Duplicate check: only within the current frame.
     * Shadowing an outer-scope name is intentional and permitted
     * (inner block variable hides outer variable of the same name). */
    if (frame_find(frame, name) != NULL)
        return SYM_ALREADY_DEFINED;

    if (frame->count >= SCOPE_MAX_ENTRIES)
        return SYM_FRAME_FULL;

    Symbol *sym = &frame->entries[frame->count];
    strncpy(sym->name, name, SYMBOL_NAME_MAX - 1);
    sym->name[SYMBOL_NAME_MAX - 1] = '\0';
    sym->type       = type;
    sym->value      = value;
    sym->is_defined = 1;
    sym->is_mutable = is_mutable;

    frame->count++;
    return SYM_OK;
}

/* ------------------------------------------------------------------ */
/* scope_lookup                                                        */
/* ------------------------------------------------------------------ */

SymResult scope_lookup(SymbolTable *st,
                       const char  *name,
                       Symbol     **out)
{
    if (st == NULL || st->top == NULL) return SYM_NO_SCOPE;
    if (name == NULL)                  return SYM_NOT_FOUND;

    /*
     * Walk from innermost frame outward — this is the environment
     * chain traversal that implements static scoping (D1 §4.6,
     * Sebesta §5.4). The first match wins, which means inner-scope
     * definitions shadow outer ones.
     */
    for (ScopeFrame *frame = st->top;
         frame != NULL;
         frame = frame->enclosing) {

        Symbol *sym = frame_find(frame, name);
        if (sym != NULL) {
            if (out != NULL) *out = sym;
            return SYM_OK;
        }
    }

    if (out != NULL) *out = NULL;
    return SYM_NOT_FOUND;
}

/* ------------------------------------------------------------------ */
/* scope_assign                                                        */
/* ------------------------------------------------------------------ */

SymResult scope_assign(SymbolTable *st,
                       const char  *name,
                       WL_Value     new_value)
{
    if (st == NULL || st->top == NULL) return SYM_NO_SCOPE;

    Symbol *sym = NULL;
    SymResult r = scope_lookup(st, name, &sym);
    if (r != SYM_OK)   return r;              /* SYM_NOT_FOUND        */
    if (!sym->is_mutable) return SYM_IMMUTABLE;

    sym->value = new_value;
    return SYM_OK;
}

/* ------------------------------------------------------------------ */
/* sym_type_name                                                       */
/* ------------------------------------------------------------------ */

const char *sym_type_name(WL_Type type)
{
    switch (type) {
        case TYPE_INT:      return "int";
        case TYPE_FLOAT:    return "float";
        case TYPE_BOOL:     return "bool";
        case TYPE_DURATION: return "duration";
        case TYPE_WEIGHT:   return "weight";
        case TYPE_DAY:      return "Day";
        default:            return "<unknown>";
    }
}

/* ------------------------------------------------------------------ */
/* sym_result_str                                                      */
/* ------------------------------------------------------------------ */

const char *sym_result_str(SymResult r)
{
    switch (r) {
        case SYM_OK:              return "ok";
        case SYM_NOT_FOUND:       return "name not found";
        case SYM_ALREADY_DEFINED: return "already defined in this scope";
        case SYM_FRAME_FULL:      return "scope frame is full";
        case SYM_NO_SCOPE:        return "no open scope";
        case SYM_IMMUTABLE:       return "symbol is read-only";
        case SYM_NAME_TOO_LONG:   return "identifier too long";
        default:                  return "<unknown result>";
    }
}

/* ------------------------------------------------------------------ */
/* sym_dump — debug only                                               */
/* ------------------------------------------------------------------ */

void sym_dump(const SymbolTable *st)
{
    if (st == NULL) {
        fprintf(stderr, "[sym_dump] NULL table\n");
        return;
    }

    const char *level_name[] = { "GLOBAL", "FUNCTION", "BLOCK" };

    int depth = 0;
    for (const ScopeFrame *frame = st->top;
         frame != NULL;
         frame = frame->enclosing, depth++) {

        fprintf(stderr, "--- frame %d  level=%s  count=%d ---\n",
                depth,
                level_name[frame->level],
                frame->count);

        for (int i = 0; i < frame->count; i++) {
            const Symbol *s = &frame->entries[i];
            if (!s->is_defined) continue;

            fprintf(stderr, "  %-24s  %-10s  %s  ",
                    s->name,
                    sym_type_name(s->type),
                    s->is_mutable ? "mut  " : "ro   ");

            switch (s->type) {
                case TYPE_INT:
                    fprintf(stderr, "%d", s->value.as_int);
                    break;
                case TYPE_FLOAT:
                    fprintf(stderr, "%g", s->value.as_float);
                    break;
                case TYPE_BOOL:
                    fprintf(stderr, "%s", s->value.as_bool ? "true" : "false");
                    break;
                case TYPE_DURATION:
                    fprintf(stderr, "%ds", s->value.as_duration);
                    break;
                case TYPE_WEIGHT:
                    fprintf(stderr, "%gkg", s->value.as_weight);
                    break;
                case TYPE_DAY:
                    fprintf(stderr, "Day{setCount=%d}",
                            s->value.as_day.set_count);
                    break;
                default:
                    fprintf(stderr, "?");
            }
            fprintf(stderr, "\n");
        }
    }

    if (depth == 0)
        fprintf(stderr, "[sym_dump] no open frames\n");
}
