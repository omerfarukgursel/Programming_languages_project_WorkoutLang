#ifndef TYPE_CHECKER_H
#define TYPE_CHECKER_H

/*
 * type_checker.h — WorkoutLang Type Checker
 *
 * Implements the static type rules declared in D1 §4.5, §4.6, §4.7.
 *
 * Two-pass design (D1 §4.5 — static type checking, Sebesta §6.11):
 *
 *   Pass 1 — tc_register_globals()
 *     Walks top-level Decl nodes and registers every workout, routine,
 *     and func name at global scope as an immutable symbol.  This makes
 *     forward references legal: a routine can call a func declared later
 *     in the file.
 *
 *   Pass 2 — tc_check_program()
 *     Walks every declaration body, opens/closes scopes, and enforces
 *     all type rules below.
 *
 * Type rules enforced (§4.5, §4.7):
 *   - BinOp:    both operands must have the same type.
 *               duration and weight are comparison-only (§4.5).
 *               bool operands restricted to && || == != (§4.5).
 *               Arithmetic restricted to int and float.
 *   - UnOp:     '-' requires int or float; '!' requires bool.
 *   - if/while: condition must be TYPE_BOOL (§4.7).
 *   - return:   expr type must match func's declared return type.
 *               return inside a routine is a type error.
 *   - var_decl: declared type must match expr type exactly (no coercion).
 *   - assign:   target must be a mutable variable in scope;
 *               new expr type must match declared type exactly (§4.6).
 *   - func_call:argument count and each argument type must match params.
 *   - Day.setCount: left side must resolve to TYPE_DAY; result is TYPE_INT.
 *   - load:     name must resolve to a TYPE_DAY or workout decl.
 *   - print:    any type accepted.
 *   - set_stmt: no type-checking needed beyond what the grammar enforces
 *               (all fields are literals).
 *
 * Error format: [line N] Type error: <message>   (printed to stderr)
 *
 * Usage:
 *   TypeChecker tc;
 *   tc_init(&tc);
 *   tc_register_globals(&tc, &program);  // pass 1
 *   int ok = tc_check_program(&tc, &program); // pass 2; returns 1 ok, 0 errors
 *   tc_free(&tc);
 */

#include "ast.h"
#include "symbol_table.h"

/* ------------------------------------------------------------------ */
/* TC_Type — type checker's view of WorkoutLang types                 */
/* Maps 1-to-1 onto WL_Type from symbol_table.h, plus TC_TYPE_UNKNOWN */
/* for error recovery (allows checking to continue after one error).  */
/* ------------------------------------------------------------------ */

typedef enum {
    TC_INT,
    TC_FLOAT,
    TC_BOOL,
    TC_DURATION,
    TC_WEIGHT,
    TC_DAY,
    TC_STRING,       /* STRING_LIT — not a declared type, print-only  */
    TC_TYPE_UNKNOWN  /* sentinel for error recovery                   */
} TC_Type;

/* ------------------------------------------------------------------ */
/* FuncSig — function signature stored at global scope                */
/* Used by func_call checking to verify arity and argument types.     */
/* ------------------------------------------------------------------ */

#define TC_MAX_PARAMS 16

typedef struct {
    TC_Type  ret;
    int      param_count;
    TC_Type  param_types[TC_MAX_PARAMS];
    char     param_names[TC_MAX_PARAMS][256];
} FuncSig;

/* ------------------------------------------------------------------ */
/* FuncSigTable — flat array of signatures, parallel to global decls  */
/* ------------------------------------------------------------------ */

#define TC_MAX_FUNCS 64

typedef struct {
    char    name[256];
    FuncSig sig;
} FuncSigEntry;

/* ------------------------------------------------------------------ */
/* TypeChecker                                                         */
/* ------------------------------------------------------------------ */

typedef struct {
    SymbolTable   st;
    FuncSigEntry  funcs[TC_MAX_FUNCS];
    int           func_count;
    int           error_count;

    /* Set while checking a func body so return can verify type.     */
    TC_Type       current_return_type;   /* TC_TYPE_UNKNOWN in routines */
    int           in_routine;            /* 1 while checking a routine  */
} TypeChecker;

/* ------------------------------------------------------------------ */
/* API                                                                 */
/* ------------------------------------------------------------------ */

/*
 * tc_init — initialise a TypeChecker.  Must be called first.
 */
void tc_init(TypeChecker *tc);

/*
 * tc_register_globals — Pass 1.
 * Registers all top-level declaration names at global scope.
 * Workouts and Day records are registered as TYPE_DAY (immutable).
 * Routines are registered as TYPE_INT sentinel (immutable).
 * Funcs are registered + their signature stored in tc->funcs[].
 * Call before tc_check_program().
 */
void tc_register_globals(TypeChecker *tc, Program *prog);

/*
 * tc_check_program — Pass 2.
 * Walks every declaration body and checks all type rules.
 * Returns 1 if no type errors were found, 0 otherwise.
 */
int tc_check_program(TypeChecker *tc, Program *prog);

/*
 * tc_free — release resources.  Call when done.
 */
void tc_free(TypeChecker *tc);

/*
 * tc_type_name — human-readable name for a TC_Type.
 * Used in error messages.
 */
const char *tc_type_name(TC_Type t);

#endif /* TYPE_CHECKER_H */
