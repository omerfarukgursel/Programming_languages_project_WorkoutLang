/*
 * type_checker.c — WorkoutLang Type Checker Implementation
 *
 * See type_checker.h for the full design note.
 *
 * Internal organisation:
 *   tc_type_from_name()   convert "int"/"float"/... string → TC_Type
 *   tc_wl_type()          TC_Type → WL_Type for symbol table calls
 *   tc_error()            emit a formatted error to stderr
 *   tc_lookup_funcsig()   find a FuncSig by function name
 *   tc_check_expr()       recursively type-check an expression, return TC_Type
 *   tc_check_stmtlist()   type-check a linked list of statements
 *   tc_check_stmt()       type-check one statement
 */

#include "type_checker.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/* tc_type_name                                                        */
/* ------------------------------------------------------------------ */

const char *tc_type_name(TC_Type t)
{
    switch (t) {
        case TC_INT:          return "int";
        case TC_FLOAT:        return "float";
        case TC_BOOL:         return "bool";
        case TC_DURATION:     return "duration";
        case TC_WEIGHT:       return "weight";
        case TC_DAY:          return "Day";
        case TC_STRING:       return "string";
        case TC_TYPE_UNKNOWN: return "<unknown>";
        default:              return "<invalid>";
    }
}

/* ------------------------------------------------------------------ */
/* Internal helpers                                                    */
/* ------------------------------------------------------------------ */

/* Convert the type-name string stored in AST nodes to TC_Type. */
static TC_Type tc_type_from_name(const char *name)
{
    if (strcmp(name, "int")      == 0) return TC_INT;
    if (strcmp(name, "float")    == 0) return TC_FLOAT;
    if (strcmp(name, "bool")     == 0) return TC_BOOL;
    if (strcmp(name, "duration") == 0) return TC_DURATION;
    if (strcmp(name, "weight")   == 0) return TC_WEIGHT;
    return TC_TYPE_UNKNOWN;
}

/* Map TC_Type → WL_Type for symbol table calls.
 * TC_STRING and TC_TYPE_UNKNOWN have no WL_Type counterpart;
 * caller must not store them in the symbol table. */
static WL_Type tc_wl_type(TC_Type t)
{
    switch (t) {
        case TC_INT:      return TYPE_INT;
        case TC_FLOAT:    return TYPE_FLOAT;
        case TC_BOOL:     return TYPE_BOOL;
        case TC_DURATION: return TYPE_DURATION;
        case TC_WEIGHT:   return TYPE_WEIGHT;
        case TC_DAY:      return TYPE_DAY;
        default:          return TYPE_INT;   /* unreachable in valid code */
    }
}

/* Emit one type error.  All errors go to stderr matching D3 format. */
static void tc_error(TypeChecker *tc, int line, const char *msg)
{
    fprintf(stderr, "[line %d] Type error: %s\n", line, msg);
    tc->error_count++;
}

/* Find a stored function signature by name; NULL if not found. */
static FuncSig *tc_lookup_funcsig(TypeChecker *tc, const char *name)
{
    for (int i = 0; i < tc->func_count; i++) {
        if (strcmp(tc->funcs[i].name, name) == 0)
            return &tc->funcs[i].sig;
    }
    return NULL;
}

/* ------------------------------------------------------------------ */
/* tc_init / tc_free                                                   */
/* ------------------------------------------------------------------ */

void tc_init(TypeChecker *tc)
{
    sym_init(&tc->st);
    tc->func_count          = 0;
    tc->error_count         = 0;
    tc->current_return_type = TC_TYPE_UNKNOWN;
    tc->in_routine          = 0;
    memset(tc->funcs, 0, sizeof(tc->funcs));
}

void tc_free(TypeChecker *tc)
{
    /* Pop any leftover frames (shouldn't be any after a clean check). */
    while (tc->st.top != NULL)
        scope_exit(&tc->st);
}

/* ------------------------------------------------------------------ */
/* Pass 1 — tc_register_globals                                        */
/* ------------------------------------------------------------------ */

void tc_register_globals(TypeChecker *tc, Program *prog)
{
    /* Open global scope — left open for the lifetime of the checker. */
    scope_enter(&tc->st, SCOPE_GLOBAL);

    for (Decl *d = prog->decls; d != NULL; d = d->next) {
        WL_Value zero = {0};

        switch (d->kind) {

        case DECL_WORKOUT: {
            /* Count Day declarations inside the workout and register
             * each day name as an immutable TYPE_DAY at global scope.
             * The workout name itself is also registered (as a DAY
             * sentinel so load-statement checking can find it). */
            int day_count = 0;
            for (DayDecl *day = d->workout.days; day != NULL; day = day->next) {
                /* Count set statements for setCount field. */
                int sc = 0;
                for (StmtList *sl = day->sets; sl != NULL; sl = sl->next) sc++;
                zero.as_day.set_count = sc;

                SymResult r = scope_define(&tc->st, day->name,
                                           TYPE_DAY, zero, /*mutable=*/0);
                if (r == SYM_ALREADY_DEFINED) {
                    char buf[768];
                    snprintf(buf, sizeof(buf),
                             "day name '%s' already declared", day->name);
                    tc_error(tc, d->line, buf);
                }
                day_count++;
            }
            /* Register the workout name itself so 'load WorkoutName'
             * can be validated.  setCount = total days. */
            zero.as_day.set_count = day_count;
            SymResult r = scope_define(&tc->st, d->name,
                                       TYPE_DAY, zero, /*mutable=*/0);
            if (r == SYM_ALREADY_DEFINED) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "workout name '%s' already declared", d->name);
                tc_error(tc, d->line, buf);
            }
            break;
        }

        case DECL_ROUTINE: {
            /* Routines have no return type; store as TYPE_BOOL sentinel.
             * Marked immutable — assigning to a routine name is an error. */
            zero.as_bool = 0;
            SymResult r = scope_define(&tc->st, d->name,
                                       TYPE_BOOL, zero, /*mutable=*/0);
            if (r == SYM_ALREADY_DEFINED) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "routine name '%s' already declared", d->name);
                tc_error(tc, d->line, buf);
            }
            break;
        }

        case DECL_FUNC: {
            /* Build and store the function signature. */
            if (tc->func_count >= TC_MAX_FUNCS) {
                tc_error(tc, d->line, "too many function declarations");
                break;
            }
            FuncSigEntry *entry = &tc->funcs[tc->func_count++];
            strncpy(entry->name, d->name, sizeof(entry->name) - 1);

            FuncSig *sig = &entry->sig;
            sig->ret = tc_type_from_name(d->func.ret_type);
            if (sig->ret == TC_TYPE_UNKNOWN) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "func '%s' has unknown return type '%s'",
                         d->name, d->func.ret_type);
                tc_error(tc, d->line, buf);
            }

            sig->param_count = 0;
            for (Param *par = d->func.params; par != NULL; par = par->next) {
                if (sig->param_count >= TC_MAX_PARAMS) {
                    tc_error(tc, d->line, "too many parameters");
                    break;
                }
                int idx = sig->param_count++;
                sig->param_types[idx] = tc_type_from_name(par->type_name);
                strncpy(sig->param_names[idx], par->name,
                        sizeof(sig->param_names[idx]) - 1);

                if (sig->param_types[idx] == TC_TYPE_UNKNOWN) {
                    char buf[768];
                    snprintf(buf, sizeof(buf),
                             "parameter '%s' of func '%s' has unknown type '%s'",
                             par->name, d->name, par->type_name);
                    tc_error(tc, d->line, buf);
                }
            }

            /* Register the func name as immutable at global scope.   */
            zero.as_int = 0;
            SymResult r = scope_define(&tc->st, d->name,
                                       TYPE_INT, zero, /*mutable=*/0);
            if (r == SYM_ALREADY_DEFINED) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "func name '%s' already declared", d->name);
                tc_error(tc, d->line, buf);
            }
            break;
        }
        } /* switch */
    }
}

/* ------------------------------------------------------------------ */
/* tc_check_expr — returns the TC_Type of the expression              */
/* On error, emits a message and returns TC_TYPE_UNKNOWN so that      */
/* checking can continue without cascading spurious errors.           */
/* ------------------------------------------------------------------ */

static TC_Type tc_check_expr(TypeChecker *tc, Expr *e)
{
    if (e == NULL) return TC_TYPE_UNKNOWN;

    switch (e->kind) {

    /* ── literals ───────────────────────────────────────────────── */
    case EXPR_INT:      return TC_INT;
    case EXPR_FLOAT:    return TC_FLOAT;
    case EXPR_BOOL:     return TC_BOOL;
    case EXPR_STRING:   return TC_STRING;
    case EXPR_DURATION: return TC_DURATION;
    case EXPR_WEIGHT:   return TC_WEIGHT;

    /* ── IDENT and IDENT.setCount ───────────────────────────────── */
    case EXPR_IDENT: {
        /*
         * The lexer/parser stores "IDENT.setCount" as a single
         * EXPR_IDENT node whose sval is "NAME.setCount".
         * Detect the dot and handle field access.
         */
        const char *dot = strchr(e->sval, '.');
        if (dot != NULL) {
            /* Field access: split at the dot. */
            char base[256] = {0};
            size_t base_len = (size_t)(dot - e->sval);
            if (base_len >= sizeof(base)) base_len = sizeof(base) - 1;
            strncpy(base, e->sval, base_len);

            const char *field = dot + 1;

            if (strcmp(field, "setCount") != 0) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "unknown field '.%s' — only '.setCount' is supported",
                         field);
                tc_error(tc, e->line, buf);
                return TC_TYPE_UNKNOWN;
            }

            Symbol *sym = NULL;
            SymResult r = scope_lookup(&tc->st, base, &sym);
            if (r != SYM_OK) {
                char buf[768];
                snprintf(buf, sizeof(buf), "undefined name '%s'", base);
                tc_error(tc, e->line, buf);
                return TC_TYPE_UNKNOWN;
            }
            if (sym->type != TYPE_DAY) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "'.setCount' requires a Day value, but '%s' is %s",
                         base, sym_type_name(sym->type));
                tc_error(tc, e->line, buf);
                return TC_TYPE_UNKNOWN;
            }
            return TC_INT;   /* Day.setCount is always int (§4.5) */
        }

        /* Plain variable reference. */
        Symbol *sym = NULL;
        SymResult r = scope_lookup(&tc->st, e->sval, &sym);
        if (r != SYM_OK) {
            char buf[768];
            snprintf(buf, sizeof(buf), "undefined variable '%s'", e->sval);
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }
        /* Map WL_Type back to TC_Type. */
        switch (sym->type) {
            case TYPE_INT:      return TC_INT;
            case TYPE_FLOAT:    return TC_FLOAT;
            case TYPE_BOOL:     return TC_BOOL;
            case TYPE_DURATION: return TC_DURATION;
            case TYPE_WEIGHT:   return TC_WEIGHT;
            case TYPE_DAY:      return TC_DAY;
            default:            return TC_TYPE_UNKNOWN;
        }
    }

    /* ── EXPR_BINOP ─────────────────────────────────────────────── */
    case EXPR_BINOP: {
        TC_Type lt = tc_check_expr(tc, e->binop.left);
        TC_Type rt = tc_check_expr(tc, e->binop.right);
        const char *op = e->binop.op;

        /* Error recovery: if either side already errored, stay quiet. */
        if (lt == TC_TYPE_UNKNOWN || rt == TC_TYPE_UNKNOWN)
            return TC_TYPE_UNKNOWN;

        /* Both operands must be the same type (§4.5 — no coercion). */
        if (lt != rt) {
            char buf[768];
            snprintf(buf, sizeof(buf),
                     "operator '%s' applied to mismatched types %s and %s",
                     op, tc_type_name(lt), tc_type_name(rt));
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }

        /* duration and weight: comparison only (§4.5). */
        int is_arith = (strcmp(op,"+") == 0 || strcmp(op,"-") == 0 ||
                        strcmp(op,"*") == 0 || strcmp(op,"/") == 0);
        if (is_arith && (lt == TC_DURATION || lt == TC_WEIGHT)) {
            char buf[768];
            snprintf(buf, sizeof(buf),
                     "arithmetic operator '%s' is not permitted on type %s "
                     "(comparison only — §4.5)",
                     op, tc_type_name(lt));
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }

        /* bool operands: only && || == != (§4.5). */
        int is_relational = (strcmp(op,"<")  == 0 || strcmp(op,"<=") == 0 ||
                             strcmp(op,">")  == 0 || strcmp(op,">=") == 0);
        if (lt == TC_BOOL && (is_arith || is_relational)) {
            char buf[768];
            snprintf(buf, sizeof(buf),
                     "operator '%s' cannot be applied to bool operands",
                     op);
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }

        /* Arithmetic on string or Day is never valid. */
        if (lt == TC_STRING || lt == TC_DAY) {
            char buf[768];
            snprintf(buf, sizeof(buf),
                     "operator '%s' cannot be applied to type %s",
                     op, tc_type_name(lt));
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }

        /* Determine result type.
         * Comparison and equality operators always yield bool.
         * Arithmetic operators yield the operand type.             */
        int is_cmp = is_relational ||
                     strcmp(op,"==") == 0 || strcmp(op,"!=") == 0;
        int is_logical = strcmp(op,"&&") == 0 || strcmp(op,"||") == 0;

        if (is_cmp || is_logical) return TC_BOOL;
        return lt;   /* arithmetic: result same type as operands      */
    }

    /* ── EXPR_UNOP ──────────────────────────────────────────────── */
    case EXPR_UNOP: {
        TC_Type ot = tc_check_expr(tc, e->unop.operand);
        const char *op = e->unop.op;

        if (ot == TC_TYPE_UNKNOWN) return TC_TYPE_UNKNOWN;

        if (strcmp(op, "-") == 0) {
            if (ot != TC_INT && ot != TC_FLOAT) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "unary '-' requires int or float, got %s",
                         tc_type_name(ot));
                tc_error(tc, e->line, buf);
                return TC_TYPE_UNKNOWN;
            }
            return ot;
        }
        if (strcmp(op, "!") == 0) {
            if (ot != TC_BOOL) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "'!' requires bool, got %s", tc_type_name(ot));
                tc_error(tc, e->line, buf);
                return TC_TYPE_UNKNOWN;
            }
            return TC_BOOL;
        }
        /* Unknown unary operator — parser should have caught this.  */
        tc_error(tc, e->line, "unknown unary operator");
        return TC_TYPE_UNKNOWN;
    }

    /* ── EXPR_CALL ──────────────────────────────────────────────── */
    case EXPR_CALL: {
        FuncSig *sig = tc_lookup_funcsig(tc, e->call.name);
        if (sig == NULL) {
            char buf[768];
            snprintf(buf, sizeof(buf),
                     "call to undefined function '%s'", e->call.name);
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }

        /* Count arguments and check each type. */
        int argc = 0;
        for (ExprList *el = e->call.args; el != NULL; el = el->next) {
            if (argc >= sig->param_count) {
                argc++;
                continue;   /* count excess args; report once below  */
            }
            TC_Type at = tc_check_expr(tc, el->expr);
            if (at != TC_TYPE_UNKNOWN && at != sig->param_types[argc]) {
                char buf[768];
                snprintf(buf, sizeof(buf),
                         "argument %d of call to '%s': expected %s, got %s",
                         argc + 1, e->call.name,
                         tc_type_name(sig->param_types[argc]),
                         tc_type_name(at));
                tc_error(tc, e->line, buf);
            }
            argc++;
        }
        if (argc != sig->param_count) {
            char buf[768];
            snprintf(buf, sizeof(buf),
                     "call to '%s' expects %d argument(s), got %d",
                     e->call.name, sig->param_count, argc);
            tc_error(tc, e->line, buf);
            return TC_TYPE_UNKNOWN;
        }

        return sig->ret;
    }

    } /* switch */

    return TC_TYPE_UNKNOWN;  /* unreachable */
}

/* ------------------------------------------------------------------ */
/* tc_check_stmt                                                       */
/* ------------------------------------------------------------------ */

static void tc_check_stmtlist(TypeChecker *tc, StmtList *sl);  /* fwd */

static void tc_check_stmt(TypeChecker *tc, Stmt *s)
{
    if (s == NULL) return;

    char buf[768];

    switch (s->kind) {

    /* ── VAR_DECL: declared type must match init expr exactly ───── */
    case STMT_VAR_DECL: {
        TC_Type declared = tc_type_from_name(s->var_decl.type_name);
        if (declared == TC_TYPE_UNKNOWN) {
            snprintf(buf, sizeof(buf),
                     "unknown type '%s' in declaration of '%s'",
                     s->var_decl.type_name, s->var_decl.name);
            tc_error(tc, s->line, buf);
            return;
        }

        TC_Type init_type = tc_check_expr(tc, s->var_decl.init);

        if (init_type != TC_TYPE_UNKNOWN && init_type != declared) {
            snprintf(buf, sizeof(buf),
                     "cannot initialise '%s' (type %s) with expression of type %s",
                     s->var_decl.name,
                     tc_type_name(declared),
                     tc_type_name(init_type));
            tc_error(tc, s->line, buf);
        }

        /* Register in symbol table regardless of type mismatch so
         * later references to the variable don't cascade errors.    */
        WL_Value zero = {0};
        SymResult r = scope_define(&tc->st, s->var_decl.name,
                                   tc_wl_type(declared), zero,
                                   /*mutable=*/1);
        if (r == SYM_ALREADY_DEFINED) {
            snprintf(buf, sizeof(buf),
                     "'%s' is already declared in this scope",
                     s->var_decl.name);
            tc_error(tc, s->line, buf);
        } else if (r == SYM_FRAME_FULL) {
            tc_error(tc, s->line, "too many variables in this scope (limit: 64)");
        }
        break;
    }

    /* ── ASSIGN: target mutable, types must match (§4.6, §4.7) ─── */
    case STMT_ASSIGN: {
        Symbol *sym = NULL;
        SymResult r = scope_lookup(&tc->st, s->assign.name, &sym);

        if (r != SYM_OK) {
            snprintf(buf, sizeof(buf),
                     "assignment to undeclared variable '%s'",
                     s->assign.name);
            tc_error(tc, s->line, buf);
            return;
        }
        if (!sym->is_mutable) {
            snprintf(buf, sizeof(buf),
                     "cannot assign to '%s' — it is a %s declaration, "
                     "not a variable (§4.6)",
                     s->assign.name, sym_type_name(sym->type));
            tc_error(tc, s->line, buf);
            return;
        }

        TC_Type val_type = tc_check_expr(tc, s->assign.value);

        /* Map symbol table type back to TC_Type for comparison. */
        TC_Type sym_tc;
        switch (sym->type) {
            case TYPE_INT:      sym_tc = TC_INT;      break;
            case TYPE_FLOAT:    sym_tc = TC_FLOAT;    break;
            case TYPE_BOOL:     sym_tc = TC_BOOL;     break;
            case TYPE_DURATION: sym_tc = TC_DURATION; break;
            case TYPE_WEIGHT:   sym_tc = TC_WEIGHT;   break;
            case TYPE_DAY:      sym_tc = TC_DAY;      break;
            default:            sym_tc = TC_TYPE_UNKNOWN;
        }

        if (val_type != TC_TYPE_UNKNOWN && val_type != sym_tc) {
            snprintf(buf, sizeof(buf),
                     "cannot assign %s expression to variable '%s' of type %s",
                     tc_type_name(val_type),
                     s->assign.name,
                     tc_type_name(sym_tc));
            tc_error(tc, s->line, buf);
        }
        break;
    }

    /* ── IF: condition must be bool (§4.7) ──────────────────────── */
    case STMT_IF: {
        TC_Type ct = tc_check_expr(tc, s->if_stmt.cond);
        if (ct != TC_TYPE_UNKNOWN && ct != TC_BOOL) {
            snprintf(buf, sizeof(buf),
                     "'if' condition must be bool, got %s (§4.7)",
                     tc_type_name(ct));
            tc_error(tc, s->line, buf);
        }
        scope_enter(&tc->st, SCOPE_BLOCK);
        tc_check_stmtlist(tc, s->if_stmt.then_body);
        scope_exit(&tc->st);

        if (s->if_stmt.else_body != NULL) {
            scope_enter(&tc->st, SCOPE_BLOCK);
            tc_check_stmtlist(tc, s->if_stmt.else_body);
            scope_exit(&tc->st);
        }
        break;
    }

    /* ── WHILE: condition must be bool (§4.7) ───────────────────── */
    case STMT_WHILE: {
        TC_Type ct = tc_check_expr(tc, s->while_stmt.cond);
        if (ct != TC_TYPE_UNKNOWN && ct != TC_BOOL) {
            snprintf(buf, sizeof(buf),
                     "'while' condition must be bool, got %s (§4.7)",
                     tc_type_name(ct));
            tc_error(tc, s->line, buf);
        }
        scope_enter(&tc->st, SCOPE_BLOCK);
        tc_check_stmtlist(tc, s->while_stmt.body);
        scope_exit(&tc->st);
        break;
    }

    /* ── REPEAT: body check only; count is always INT_LIT ───────── */
    case STMT_REPEAT: {
        scope_enter(&tc->st, SCOPE_BLOCK);
        tc_check_stmtlist(tc, s->repeat_stmt.body);
        scope_exit(&tc->st);
        break;
    }

    /* ── LOAD: name must resolve to a known workout/Day (§4.4) ──── */
    case STMT_LOAD: {
        Symbol *sym = NULL;
        SymResult r = scope_lookup(&tc->st, s->load_stmt.name, &sym);
        if (r != SYM_OK) {
            snprintf(buf, sizeof(buf),
                     "'load' refers to unknown workout '%s'",
                     s->load_stmt.name);
            tc_error(tc, s->line, buf);
        } else if (sym->type != TYPE_DAY) {
            snprintf(buf, sizeof(buf),
                     "'load' requires a workout name, but '%s' is %s",
                     s->load_stmt.name, sym_type_name(sym->type));
            tc_error(tc, s->line, buf);
        }
        break;
    }

    /* ── PRINT: any type is accepted ────────────────────────────── */
    case STMT_PRINT:
        tc_check_expr(tc, s->print_stmt.value);
        break;

    /* ── RETURN: type must match current function's return type ──── */
    case STMT_RETURN: {
        if (tc->in_routine) {
            tc_error(tc, s->line,
                     "'return' is not permitted inside a routine — "
                     "only inside a func declaration");
            break;
        }
        if (tc->current_return_type == TC_TYPE_UNKNOWN) {
            /* Shouldn't happen if pass 1 ran correctly. */
            tc_error(tc, s->line, "'return' outside of any func");
            break;
        }
        TC_Type rt = tc_check_expr(tc, s->return_stmt.value);
        if (rt != TC_TYPE_UNKNOWN &&
            rt != tc->current_return_type) {
            snprintf(buf, sizeof(buf),
                     "'return' expression is %s but func return type is %s",
                     tc_type_name(rt),
                     tc_type_name(tc->current_return_type));
            tc_error(tc, s->line, buf);
        }
        break;
    }

    /* ── SET: grammar enforces literals; no further type check ───── */
    case STMT_SET:
        break;

    /* ── EXPR (bare expression statement) ───────────────────────── */
    case STMT_EXPR:
        tc_check_expr(tc, s->expr_stmt.expr);
        break;

    } /* switch */
}

/* ------------------------------------------------------------------ */
/* tc_check_stmtlist — walk a linked list of statements               */
/* ------------------------------------------------------------------ */

static void tc_check_stmtlist(TypeChecker *tc, StmtList *sl)
{
    for (; sl != NULL; sl = sl->next)
        tc_check_stmt(tc, sl->stmt);
}

/* ------------------------------------------------------------------ */
/* Pass 2 — tc_check_program                                          */
/* ------------------------------------------------------------------ */

int tc_check_program(TypeChecker *tc, Program *prog)
{
    for (Decl *d = prog->decls; d != NULL; d = d->next) {
        switch (d->kind) {

        case DECL_WORKOUT:
            /* Workout bodies contain only set_stmt nodes, which the
             * grammar guarantees are valid literals.  Nothing to check. */
            break;

        case DECL_ROUTINE: {
            /* Open a function-level scope for the routine body. */
            scope_enter(&tc->st, SCOPE_FUNCTION);
            tc->in_routine          = 1;
            tc->current_return_type = TC_TYPE_UNKNOWN;

            tc_check_stmtlist(tc, d->routine.body);

            tc->in_routine          = 0;
            tc->current_return_type = TC_TYPE_UNKNOWN;
            scope_exit(&tc->st);
            break;
        }

        case DECL_FUNC: {
            FuncSig *sig = tc_lookup_funcsig(tc, d->name);
            if (sig == NULL) break;   /* pass 1 error; skip */

            scope_enter(&tc->st, SCOPE_FUNCTION);
            tc->in_routine          = 0;
            tc->current_return_type = sig->ret;

            /* Register parameters as mutable locals. */
            WL_Value zero = {0};
            for (int i = 0; i < sig->param_count; i++) {
                scope_define(&tc->st,
                             sig->param_names[i],
                             tc_wl_type(sig->param_types[i]),
                             zero,
                             /*mutable=*/1);
            }

            tc_check_stmtlist(tc, d->func.body);

            tc->current_return_type = TC_TYPE_UNKNOWN;
            scope_exit(&tc->st);
            break;
        }
        } /* switch */
    }

    return (tc->error_count == 0) ? 1 : 0;
}
