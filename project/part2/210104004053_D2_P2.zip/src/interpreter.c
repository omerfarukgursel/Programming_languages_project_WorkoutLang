/*
 * interpreter.c — WorkoutLang Tree-Walking Interpreter
 *
 * Execution strategy: single-pass AST walk.
 * The SymbolTable environment chain is the runtime stack (D1 §4.6):
 *   - SCOPE_GLOBAL holds workout/routine/func names (immutable)
 *   - SCOPE_FUNCTION is pushed on each routine/func call entry
 *   - SCOPE_BLOCK is pushed on each if/while/repeat body entry
 *
 * Return values from functions are communicated through a ReturnSignal
 * struct rather than through a global or setjmp, keeping control flow
 * explicit and easy to audit.
 *
 * Duration literals are stored internally as seconds (int32_t).
 * Weight literals are stored internally as kilograms (double).
 * The format helpers convert back to human-readable units for output.
 */

#include "interpreter.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ------------------------------------------------------------------ */
/* Internal types                                                      */
/* ------------------------------------------------------------------ */

/*
 * ReturnSignal — used to propagate a return value from a func body
 * back to the call site without unwinding through intermediate frames
 * manually.  Every statement executor checks fired after each stmt.
 */
typedef struct {
    int   fired;   /* 1 if a return stmt was executed                 */
    RtVal value;
} ReturnSignal;

/* ------------------------------------------------------------------ */
/* Forward declarations                                                */
/* ------------------------------------------------------------------ */

static RtVal        eval_expr    (Interpreter *ip, Expr     *e);
static ReturnSignal exec_stmts   (Interpreter *ip, StmtList *sl);
static ReturnSignal exec_stmt    (Interpreter *ip, Stmt     *s);

/* ------------------------------------------------------------------ */
/* Runtime error                                                       */
/* ------------------------------------------------------------------ */

static void rt_error(Interpreter *ip, int line, const char *msg)
{
    fprintf(stderr, "[line %d] Runtime error: %s\n", line, msg);
    ip->error_count++;
}

/* A zero RtVal used as a safe return after emitting a runtime error. */
static RtVal error_val(void)
{
    RtVal v; v.type = TYPE_INT; v.val.as_int = 0; return v;
}

/* ------------------------------------------------------------------ */
/* Duration / weight format helpers                                    */
/* ------------------------------------------------------------------ */

/*
 * fmt_duration — convert internal seconds to the most readable unit.
 * Writes into buf (caller supplies, at least 32 bytes).
 */
static void fmt_duration(int32_t secs, char *buf, size_t bufsz)
{
    if (secs % 3600 == 0)
        snprintf(buf, bufsz, "%dhr",  (int)(secs / 3600));
    else if (secs % 60 == 0)
        snprintf(buf, bufsz, "%dmin", (int)(secs / 60));
    else
        snprintf(buf, bufsz, "%ds",   (int)secs);
}

/*
 * parse_duration_literal — convert the lexer's raw string (e.g. "90s",
 * "2min", "1hr") to seconds.  Returns -1 on parse failure.
 */
static int32_t parse_duration_literal(const char *s)
{
    char *end = NULL;
    long  n   = strtol(s, &end, 10);
    if (end == s) return -1;
    if (strcmp(end, "s")   == 0) return (int32_t)n;
    if (strcmp(end, "min") == 0) return (int32_t)(n * 60);
    if (strcmp(end, "hr")  == 0) return (int32_t)(n * 3600);
    return -1;
}

/*
 * parse_weight_literal — convert "80kg" or "135lb" to kilograms.
 */
static double parse_weight_literal(const char *s)
{
    char *end = NULL;
    double n  = strtod(s, &end);
    if (end == s) return -1.0;
    if (strcmp(end, "kg") == 0) return n;
    if (strcmp(end, "lb") == 0) return n * 0.45359237;
    return -1.0;
}

/* ------------------------------------------------------------------ */
/* print_rtval — write a value to stdout in the D3 output format      */
/* ------------------------------------------------------------------ */

static void print_rtval(RtVal v)
{
    char dur_buf[32];
    switch (v.type) {
        case TYPE_INT:
            printf("%d\n", (int)v.val.as_int);
            break;
        case TYPE_FLOAT:
            /* Use %g to suppress trailing zeros (3.0 → "3", 3.14 → "3.14") */
            printf("%g\n", v.val.as_float);
            break;
        case TYPE_BOOL:
            printf("%s\n", v.val.as_bool ? "true" : "false");
            break;
        case TYPE_DURATION:
            fmt_duration(v.val.as_duration, dur_buf, sizeof(dur_buf));
            printf("%s\n", dur_buf);
            break;
        case TYPE_WEIGHT:
            printf("%gkg\n", v.val.as_weight);
            break;
        case TYPE_DAY:
            printf("Day(setCount=%d)\n", (int)v.val.as_day.set_count);
            break;
    }
}

/* ------------------------------------------------------------------ */
/* Lookup helpers                                                      */
/* ------------------------------------------------------------------ */

static Decl *find_workout(Interpreter *ip, const char *name)
{
    for (int i = 0; i < ip->workout_count; i++)
        if (strcmp(ip->workouts[i].name, name) == 0)
            return ip->workouts[i].decl;
    return NULL;
}

static Decl *find_func(Interpreter *ip, const char *name)
{
    for (int i = 0; i < ip->func_count; i++)
        if (strcmp(ip->funcs[i].name, name) == 0)
            return ip->funcs[i].decl;
    return NULL;
}

/* ------------------------------------------------------------------ */
/* eval_expr — evaluate an expression to an RtVal                     */
/* ------------------------------------------------------------------ */

static RtVal eval_expr(Interpreter *ip, Expr *e)
{
    if (e == NULL) return error_val();

    char msg[512];

    switch (e->kind) {

    /* ── literals ───────────────────────────────────────────────── */
    case EXPR_INT:
        return rtval_int(e->ival);

    case EXPR_FLOAT:
        return rtval_float(e->fval);

    case EXPR_BOOL:
        return rtval_bool(e->bval);

    case EXPR_STRING: {
        /*
         * Strings are not a runtime type — they only appear in print.
         * Represent as TYPE_INT sentinel; the print handler special-
         * cases EXPR_STRING before calling eval_expr.
         * If we land here, return a dummy and let the caller handle it.
         */
        RtVal r; r.type = TYPE_INT; r.val.as_int = 0; return r;
    }

    case EXPR_DURATION: {
        int32_t secs = parse_duration_literal(e->sval);
        if (secs < 0) {
            rt_error(ip, e->line, "invalid duration literal");
            return error_val();
        }
        return rtval_duration(secs);
    }

    case EXPR_WEIGHT: {
        double kg = parse_weight_literal(e->sval);
        if (kg < 0.0) {
            rt_error(ip, e->line, "invalid weight literal");
            return error_val();
        }
        return rtval_weight(kg);
    }

    /* ── IDENT / IDENT.setCount ─────────────────────────────────── */
    case EXPR_IDENT: {
        const char *dot = strchr(e->sval, '.');
        if (dot != NULL) {
            /* Field access: IDENT.setCount */
            char base[256] = {0};
            size_t len = (size_t)(dot - e->sval);
            if (len >= sizeof(base)) len = sizeof(base) - 1;
            strncpy(base, e->sval, len);

            Symbol *sym = NULL;
            if (scope_lookup(&ip->st, base, &sym) != SYM_OK) {
                snprintf(msg, sizeof(msg), "undefined name '%s'", base);
                rt_error(ip, e->line, msg);
                return error_val();
            }
            if (sym->type != TYPE_DAY) {
                snprintf(msg, sizeof(msg),
                         "'.setCount' applied to non-Day value '%s'", base);
                rt_error(ip, e->line, msg);
                return error_val();
            }
            return rtval_int(sym->value.as_day.set_count);
        }

        /* Plain variable or global name lookup */
        Symbol *sym = NULL;
        if (scope_lookup(&ip->st, e->sval, &sym) != SYM_OK) {
            snprintf(msg, sizeof(msg),
                     "undefined variable '%s'", e->sval);
            rt_error(ip, e->line, msg);
            return error_val();
        }
        RtVal r;
        r.type = sym->type;
        r.val  = sym->value;
        return r;
    }

    /* ── BINOP ──────────────────────────────────────────────────── */
    case EXPR_BINOP: {
        const char *op = e->binop.op;

        /*
         * Short-circuit evaluation for && and || (D1 §4.7).
         * Evaluate left; only evaluate right if needed.
         */
        if (strcmp(op, "&&") == 0) {
            RtVal lv = eval_expr(ip, e->binop.left);
            if (!lv.val.as_bool) return rtval_bool(0);
            RtVal rv = eval_expr(ip, e->binop.right);
            return rtval_bool(rv.val.as_bool);
        }
        if (strcmp(op, "||") == 0) {
            RtVal lv = eval_expr(ip, e->binop.left);
            if (lv.val.as_bool)  return rtval_bool(1);
            RtVal rv = eval_expr(ip, e->binop.right);
            return rtval_bool(rv.val.as_bool);
        }

        /* Left-to-right evaluation for all other operators (§4.7). */
        RtVal lv = eval_expr(ip, e->binop.left);
        RtVal rv = eval_expr(ip, e->binop.right);

        /* ── comparison operators (work on int, float, bool,        */
        /*    duration, weight — type checker guarantees same type)  */
        if (strcmp(op, "==") == 0) {
            switch (lv.type) {
                case TYPE_INT:      return rtval_bool(lv.val.as_int      == rv.val.as_int);
                case TYPE_FLOAT:    return rtval_bool(lv.val.as_float    == rv.val.as_float);
                case TYPE_BOOL:     return rtval_bool(lv.val.as_bool     == rv.val.as_bool);
                case TYPE_DURATION: return rtval_bool(lv.val.as_duration == rv.val.as_duration);
                case TYPE_WEIGHT:   return rtval_bool(lv.val.as_weight   == rv.val.as_weight);
                default:            return rtval_bool(0);
            }
        }
        if (strcmp(op, "!=") == 0) {
            switch (lv.type) {
                case TYPE_INT:      return rtval_bool(lv.val.as_int      != rv.val.as_int);
                case TYPE_FLOAT:    return rtval_bool(lv.val.as_float    != rv.val.as_float);
                case TYPE_BOOL:     return rtval_bool(lv.val.as_bool     != rv.val.as_bool);
                case TYPE_DURATION: return rtval_bool(lv.val.as_duration != rv.val.as_duration);
                case TYPE_WEIGHT:   return rtval_bool(lv.val.as_weight   != rv.val.as_weight);
                default:            return rtval_bool(0);
            }
        }
        if (strcmp(op, "<") == 0) {
            if (lv.type == TYPE_INT)      return rtval_bool(lv.val.as_int      < rv.val.as_int);
            if (lv.type == TYPE_FLOAT)    return rtval_bool(lv.val.as_float    < rv.val.as_float);
            if (lv.type == TYPE_DURATION) return rtval_bool(lv.val.as_duration < rv.val.as_duration);
            if (lv.type == TYPE_WEIGHT)   return rtval_bool(lv.val.as_weight   < rv.val.as_weight);
        }
        if (strcmp(op, "<=") == 0) {
            if (lv.type == TYPE_INT)      return rtval_bool(lv.val.as_int      <= rv.val.as_int);
            if (lv.type == TYPE_FLOAT)    return rtval_bool(lv.val.as_float    <= rv.val.as_float);
            if (lv.type == TYPE_DURATION) return rtval_bool(lv.val.as_duration <= rv.val.as_duration);
            if (lv.type == TYPE_WEIGHT)   return rtval_bool(lv.val.as_weight   <= rv.val.as_weight);
        }
        if (strcmp(op, ">") == 0) {
            if (lv.type == TYPE_INT)      return rtval_bool(lv.val.as_int      > rv.val.as_int);
            if (lv.type == TYPE_FLOAT)    return rtval_bool(lv.val.as_float    > rv.val.as_float);
            if (lv.type == TYPE_DURATION) return rtval_bool(lv.val.as_duration > rv.val.as_duration);
            if (lv.type == TYPE_WEIGHT)   return rtval_bool(lv.val.as_weight   > rv.val.as_weight);
        }
        if (strcmp(op, ">=") == 0) {
            if (lv.type == TYPE_INT)      return rtval_bool(lv.val.as_int      >= rv.val.as_int);
            if (lv.type == TYPE_FLOAT)    return rtval_bool(lv.val.as_float    >= rv.val.as_float);
            if (lv.type == TYPE_DURATION) return rtval_bool(lv.val.as_duration >= rv.val.as_duration);
            if (lv.type == TYPE_WEIGHT)   return rtval_bool(lv.val.as_weight   >= rv.val.as_weight);
        }

        /* ── arithmetic operators (int and float only; type checker  */
        /*    has already blocked duration/weight/bool arithmetic)    */
        if (strcmp(op, "+") == 0) {
            if (lv.type == TYPE_INT)   return rtval_int(lv.val.as_int + rv.val.as_int);
            if (lv.type == TYPE_FLOAT) return rtval_float(lv.val.as_float + rv.val.as_float);
        }
        if (strcmp(op, "-") == 0) {
            if (lv.type == TYPE_INT)   return rtval_int(lv.val.as_int - rv.val.as_int);
            if (lv.type == TYPE_FLOAT) return rtval_float(lv.val.as_float - rv.val.as_float);
        }
        if (strcmp(op, "*") == 0) {
            if (lv.type == TYPE_INT)   return rtval_int(lv.val.as_int * rv.val.as_int);
            if (lv.type == TYPE_FLOAT) return rtval_float(lv.val.as_float * rv.val.as_float);
        }
        if (strcmp(op, "/") == 0) {
            if (lv.type == TYPE_INT) {
                if (rv.val.as_int == 0) {
                    rt_error(ip, e->line, "division by zero");
                    return error_val();
                }
                return rtval_int(lv.val.as_int / rv.val.as_int);
            }
            if (lv.type == TYPE_FLOAT) {
                if (rv.val.as_float == 0.0) {
                    rt_error(ip, e->line, "division by zero");
                    return error_val();
                }
                return rtval_float(lv.val.as_float / rv.val.as_float);
            }
        }

        snprintf(msg, sizeof(msg),
                 "unknown binary operator '%s'", op);
        rt_error(ip, e->line, msg);
        return error_val();
    }

    /* ── UNOP ───────────────────────────────────────────────────── */
    case EXPR_UNOP: {
        RtVal ov = eval_expr(ip, e->unop.operand);
        const char *op = e->unop.op;

        if (strcmp(op, "-") == 0) {
            if (ov.type == TYPE_INT)   return rtval_int(-ov.val.as_int);
            if (ov.type == TYPE_FLOAT) return rtval_float(-ov.val.as_float);
        }
        if (strcmp(op, "!") == 0) {
            return rtval_bool(!ov.val.as_bool);
        }

        snprintf(msg, sizeof(msg), "unknown unary operator '%s'", op);
        rt_error(ip, e->line, msg);
        return error_val();
    }

    /* ── CALL ───────────────────────────────────────────────────── */
    case EXPR_CALL: {
        Decl *func_decl = find_func(ip, e->call.name);
        if (func_decl == NULL) {
            snprintf(msg, sizeof(msg),
                     "undefined function '%s'", e->call.name);
            rt_error(ip, e->line, msg);
            return error_val();
        }

        /*
         * Evaluate all arguments in the CALLER'S scope before opening
         * a new frame.  This is call-by-value (D1 §4.6, Sebesta §9.2):
         * the callee gets copies; mutations inside the func body do not
         * affect the caller's environment.
         */
        RtVal argv[16];
        int   argc = 0;
        for (ExprList *el = e->call.args;
             el != NULL && argc < 16;
             el = el->next) {
            argv[argc++] = eval_expr(ip, el->expr);
        }

        /* Open a new function scope for the callee. */
        scope_enter(&ip->st, SCOPE_FUNCTION);

        /* Bind parameters to their argument values. */
        Param *par = func_decl->func.params;
        for (int i = 0; i < argc && par != NULL; i++, par = par->next) {
            WL_Type wt;
            if      (strcmp(par->type_name, "int")      == 0) wt = TYPE_INT;
            else if (strcmp(par->type_name, "float")    == 0) wt = TYPE_FLOAT;
            else if (strcmp(par->type_name, "bool")     == 0) wt = TYPE_BOOL;
            else if (strcmp(par->type_name, "duration") == 0) wt = TYPE_DURATION;
            else if (strcmp(par->type_name, "weight")   == 0) wt = TYPE_WEIGHT;
            else                                               wt = TYPE_INT;

            scope_define(&ip->st, par->name, wt, argv[i].val, /*mutable=*/1);
        }

        /* Execute the function body. */
        ReturnSignal sig = exec_stmts(ip, func_decl->func.body);

        scope_exit(&ip->st);

        if (sig.fired) return sig.value;

        /* Function fell off the end without returning — return 0. */
        return rtval_int(0);
    }

    } /* switch */

    return error_val();
}

/* ------------------------------------------------------------------ */
/* exec_set_stmt — execute a set statement (domain output)            */
/* ------------------------------------------------------------------ */

static void exec_set_stmt(Interpreter *ip, Stmt *s)
{
    /* Parse the stored duration literal string for display. */
    int32_t secs = parse_duration_literal(s->set_stmt.rest);
    char dur_buf[32] = "?";
    if (secs >= 0) fmt_duration(secs, dur_buf, sizeof(dur_buf));

    printf("  set %s: %d x %d, rest %s\n",
           s->set_stmt.name,
           s->set_stmt.sets,
           s->set_stmt.reps,
           dur_buf);

    (void)ip;  /* ip unused here; kept for consistent signature       */
}

/* ------------------------------------------------------------------ */
/* exec_load — execute a load statement                               */
/* ------------------------------------------------------------------ */

static void exec_load(Interpreter *ip, Stmt *s)
{
    Decl *workout = find_workout(ip, s->load_stmt.name);
    if (workout == NULL) {
        char msg[512];
        snprintf(msg, sizeof(msg),
                 "load: unknown workout '%s'", s->load_stmt.name);
        rt_error(ip, s->line, msg);
        return;
    }

    /* Execute every day in declaration order. */
    for (DayDecl *day = workout->workout.days;
         day != NULL;
         day = day->next) {

        printf("[%s — %s]\n", workout->name, day->name);

        /* Execute every set_stmt in this day. */
        for (StmtList *sl = day->sets; sl != NULL; sl = sl->next) {
            if (sl->stmt != NULL && sl->stmt->kind == STMT_SET)
                exec_set_stmt(ip, sl->stmt);
        }
    }
}

/* ------------------------------------------------------------------ */
/* exec_stmt — execute one statement; returns a ReturnSignal          */
/* ------------------------------------------------------------------ */

static ReturnSignal no_return(void)
{
    ReturnSignal s; s.fired = 0; s.value = error_val(); return s;
}

static ReturnSignal make_return(RtVal v)
{
    ReturnSignal s; s.fired = 1; s.value = v; return s;
}

static ReturnSignal exec_stmt(Interpreter *ip, Stmt *s)
{
    if (s == NULL) return no_return();

    char msg[512];

    switch (s->kind) {

    /* ── VAR_DECL ───────────────────────────────────────────────── */
    case STMT_VAR_DECL: {
        RtVal init = eval_expr(ip, s->var_decl.init);

        WL_Type wt;
        if      (strcmp(s->var_decl.type_name, "int")      == 0) wt = TYPE_INT;
        else if (strcmp(s->var_decl.type_name, "float")    == 0) wt = TYPE_FLOAT;
        else if (strcmp(s->var_decl.type_name, "bool")     == 0) wt = TYPE_BOOL;
        else if (strcmp(s->var_decl.type_name, "duration") == 0) wt = TYPE_DURATION;
        else if (strcmp(s->var_decl.type_name, "weight")   == 0) wt = TYPE_WEIGHT;
        else                                                       wt = TYPE_INT;

        SymResult r = scope_define(&ip->st, s->var_decl.name,
                                   wt, init.val, /*mutable=*/1);
        if (r == SYM_ALREADY_DEFINED) {
            snprintf(msg, sizeof(msg),
                     "'%s' already declared in this scope",
                     s->var_decl.name);
            rt_error(ip, s->line, msg);
        } else if (r == SYM_FRAME_FULL) {
            rt_error(ip, s->line, "too many variables in this scope (limit: 64)");
        }
        return no_return();
    }

    /* ── ASSIGN ─────────────────────────────────────────────────── */
    case STMT_ASSIGN: {
        RtVal rhs = eval_expr(ip, s->assign.value);
        SymResult r = scope_assign(&ip->st, s->assign.name, rhs.val);
        if (r == SYM_NOT_FOUND) {
            snprintf(msg, sizeof(msg),
                     "assignment to undeclared variable '%s'",
                     s->assign.name);
            rt_error(ip, s->line, msg);
        } else if (r == SYM_IMMUTABLE) {
            snprintf(msg, sizeof(msg),
                     "cannot assign to '%s' — it is a declaration, not a variable",
                     s->assign.name);
            rt_error(ip, s->line, msg);
        }
        return no_return();
    }

    /* ── IF / ELSE ──────────────────────────────────────────────── */
    case STMT_IF: {
        RtVal cond = eval_expr(ip, s->if_stmt.cond);
        StmtList *branch = cond.val.as_bool
                           ? s->if_stmt.then_body
                           : s->if_stmt.else_body;

        if (branch != NULL) {
            scope_enter(&ip->st, SCOPE_BLOCK);
            ReturnSignal sig = exec_stmts(ip, branch);
            scope_exit(&ip->st);
            if (sig.fired) return sig;
        }
        return no_return();
    }

    /* ── WHILE ──────────────────────────────────────────────────── */
    case STMT_WHILE: {
        /*
         * The condition is re-evaluated on every iteration against the
         * updated environment — matching the W-True semantic rule in
         * D1 §4.4.  Block-local variables are destroyed on each
         * scope_exit (stack-dynamic lifetime, §4.6).
         */
        while (1) {
            RtVal cond = eval_expr(ip, s->while_stmt.cond);
            if (!cond.val.as_bool) break;           /* W-False rule   */

            scope_enter(&ip->st, SCOPE_BLOCK);
            ReturnSignal sig = exec_stmts(ip, s->while_stmt.body);
            scope_exit(&ip->st);

            if (sig.fired) return sig;              /* propagate return */
            if (ip->error_count > 0) break;         /* halt on error   */
        }
        return no_return();
    }

    /* ── REPEAT N WEEKS ─────────────────────────────────────────── */
    case STMT_REPEAT: {
        /*
         * The count is stored as INT_LIT in the AST (parser guarantees
         * this), so it is fixed at parse time — not evaluated each
         * iteration.  This matches the repeat semantic in D1 §4.4 and
         * §4.3: "INT_LIT is evaluated once before the loop begins."
         *
         * No iteration counter is exposed to the body (D1 §4.8 ¶6).
         */
        int n = s->repeat_stmt.count;
        for (int i = 0; i < n; i++) {
            scope_enter(&ip->st, SCOPE_BLOCK);
            ReturnSignal sig = exec_stmts(ip, s->repeat_stmt.body);
            scope_exit(&ip->st);

            if (sig.fired) return sig;
            if (ip->error_count > 0) break;
        }
        return no_return();
    }

    /* ── LOAD ───────────────────────────────────────────────────── */
    case STMT_LOAD:
        exec_load(ip, s);
        return no_return();

    /* ── PRINT ──────────────────────────────────────────────────── */
    case STMT_PRINT: {
        Expr *val_expr = s->print_stmt.value;

        /*
         * Special-case EXPR_STRING: the string value lives in sval
         * and is not stored in the symbol table, so we print it
         * directly rather than through eval_expr.
         */
        if (val_expr != NULL && val_expr->kind == EXPR_STRING) {
            printf("%s\n", val_expr->sval);
        } else {
            RtVal v = eval_expr(ip, val_expr);
            print_rtval(v);
        }
        return no_return();
    }

    /* ── RETURN ─────────────────────────────────────────────────── */
    case STMT_RETURN: {
        RtVal v = eval_expr(ip, s->return_stmt.value);
        return make_return(v);
    }

    /* ── SET (domain-specific output) ───────────────────────────── */
    case STMT_SET:
        exec_set_stmt(ip, s);
        return no_return();

    /* ── STMT_EXPR (bare expression — side effects only) ────────── */
    case STMT_EXPR:
        eval_expr(ip, s->expr_stmt.expr);
        return no_return();

    } /* switch */

    return no_return();
}

/* ------------------------------------------------------------------ */
/* exec_stmts — walk a StmtList, propagating ReturnSignal             */
/* ------------------------------------------------------------------ */

static ReturnSignal exec_stmts(Interpreter *ip, StmtList *sl)
{
    for (; sl != NULL; sl = sl->next) {
        ReturnSignal sig = exec_stmt(ip, sl->stmt);
        /* Propagate return or stop on runtime error. */
        if (sig.fired || ip->error_count > 0) return sig;
    }
    return no_return();
}

/* ------------------------------------------------------------------ */
/* interp_init — initialise and register global declarations          */
/* ------------------------------------------------------------------ */

void interp_init(Interpreter *ip, Program *prog)
{
    sym_init(&ip->st);
    ip->workout_count = 0;
    ip->func_count    = 0;
    ip->error_count   = 0;

    scope_enter(&ip->st, SCOPE_GLOBAL);

    WL_Value zero = {0};

    for (Decl *d = prog->decls; d != NULL; d = d->next) {
        switch (d->kind) {

        case DECL_WORKOUT: {
            /* Register each day as an immutable TYPE_DAY symbol.     */
            for (DayDecl *day = d->workout.days;
                 day != NULL; day = day->next) {
                int sc = 0;
                for (StmtList *sl = day->sets; sl != NULL; sl = sl->next) sc++;
                zero.as_day.set_count = sc;
                scope_define(&ip->st, day->name,
                             TYPE_DAY, zero, /*mutable=*/0);
            }
            /* Register the workout name itself. */
            zero.as_day.set_count = 0;
            scope_define(&ip->st, d->name,
                         TYPE_DAY, zero, /*mutable=*/0);

            /* Store in the workout lookup table for load. */
            if (ip->workout_count < INTERP_MAX_WORKOUTS) {
                strncpy(ip->workouts[ip->workout_count].name,
                        d->name, 255);
                ip->workouts[ip->workout_count].decl = d;
                ip->workout_count++;
            }
            break;
        }

        case DECL_ROUTINE:
            /* Routine names are immutable globals (not callable by    */
            /* name in the current grammar).                           */
            zero.as_int = 0;
            scope_define(&ip->st, d->name,
                         TYPE_INT, zero, /*mutable=*/0);
            break;

        case DECL_FUNC:
            /* Register the func name as an immutable global.         */
            zero.as_int = 0;
            scope_define(&ip->st, d->name,
                         TYPE_INT, zero, /*mutable=*/0);

            /* Store in the func lookup table for EXPR_CALL.          */
            if (ip->func_count < INTERP_MAX_FUNCS) {
                strncpy(ip->funcs[ip->func_count].name,
                        d->name, 255);
                ip->funcs[ip->func_count].decl = d;
                ip->func_count++;
            }
            break;
        }
    }
}

/* ------------------------------------------------------------------ */
/* interp_run — execute the program                                   */
/* ------------------------------------------------------------------ */

int interp_run(Interpreter *ip, Program *prog)
{
    for (Decl *d = prog->decls; d != NULL; d = d->next) {
        if (d->kind != DECL_ROUTINE) continue;   /* skip workouts/funcs */

        scope_enter(&ip->st, SCOPE_FUNCTION);
        exec_stmts(ip, d->routine.body);
        scope_exit(&ip->st);

        if (ip->error_count > 0) return 0;
    }
    return (ip->error_count == 0) ? 1 : 0;
}

/* ------------------------------------------------------------------ */
/* interp_free                                                         */
/* ------------------------------------------------------------------ */

void interp_free(Interpreter *ip)
{
    while (ip->st.top != NULL)
        scope_exit(&ip->st);
}
