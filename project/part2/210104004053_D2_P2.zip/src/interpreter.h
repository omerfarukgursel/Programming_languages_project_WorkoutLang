#ifndef INTERPRETER_H
#define INTERPRETER_H

/*
 * interpreter.h — WorkoutLang Tree-Walking Interpreter
 *
 * Executes a type-checked Program by walking the AST directly.
 * Uses the existing SymbolTable (symbol_table.h) for the environment
 * chain, matching the static scoping rule in D1 §4.6.
 *
 * Execution model:
 *   interp_init()       — call once; opens global scope, registers all
 *                         top-level declarations as immutable globals.
 *   interp_run()        — walks Decl list; executes every routine body
 *                         in declaration order.  Funcs are only executed
 *                         when called, not at top level.
 *   interp_free()       — pops all remaining scope frames, releases any
 *                         other resources.
 *
 * Statements executed (D1 §4.3):
 *   STMT_VAR_DECL  — evaluate init expr, define mutable variable in scope
 *   STMT_ASSIGN    — evaluate rhs, call scope_assign on the target name
 *   STMT_IF        — evaluate bool condition, execute then or else body
 *   STMT_WHILE     — re-evaluate bool condition each iteration (§4.4 W-True)
 *   STMT_REPEAT    — evaluate INT_LIT count once, run body N times (§4.4)
 *   STMT_LOAD      — look up workout by name, execute every day's set stmts
 *   STMT_PRINT     — evaluate expr, write formatted value to stdout
 *   STMT_RETURN    — evaluate expr, signal return to the enclosing func call
 *   STMT_SET       — print exercise log line to stdout (domain output)
 *   STMT_EXPR      — evaluate expr for side effects (func calls)
 *
 * Runtime errors (printed to stderr, execution halts):
 *   Division by zero (int and float)
 *   Undefined variable (should not occur after type checking)
 *   Wrong type at runtime (guard only; should not occur after type checking)
 *
 * Output formats:
 *   set_stmt  → "  set <exercise>: <sets> x <reps>, rest <duration>\n"
 *   print str → "<string contents>\n"
 *   print int → "<integer>\n"
 *   print float→ "<float>\n"
 *   print bool → "true\n" or "false\n"
 *   print dur  → "<N>s\n"  or  "<N>min\n"  or  "<N>hr\n"
 *   print wt   → "<N>kg\n"
 */

#include "ast.h"
#include "symbol_table.h"

/* ------------------------------------------------------------------ */
/* Runtime value                                                       */
/*                                                                     */
/* The interpreter carries type alongside value so runtime error      */
/* messages can name the actual type rather than printing a raw int.  */
/* ------------------------------------------------------------------ */

typedef struct {
    WL_Type  type;
    WL_Value val;
} RtVal;

/* Convenience constructors */
static inline RtVal rtval_int(int32_t v)
    { RtVal r; r.type = TYPE_INT;      r.val.as_int      = v; return r; }
static inline RtVal rtval_float(double v)
    { RtVal r; r.type = TYPE_FLOAT;    r.val.as_float    = v; return r; }
static inline RtVal rtval_bool(int v)
    { RtVal r; r.type = TYPE_BOOL;     r.val.as_bool     = v; return r; }
static inline RtVal rtval_duration(int32_t v)
    { RtVal r; r.type = TYPE_DURATION; r.val.as_duration = v; return r; }
static inline RtVal rtval_weight(double v)
    { RtVal r; r.type = TYPE_WEIGHT;   r.val.as_weight   = v; return r; }
static inline RtVal rtval_day(int32_t sc)
    { RtVal r; r.type = TYPE_DAY;      r.val.as_day.set_count = sc; return r; }

/* ------------------------------------------------------------------ */
/* WorkoutEntry — maps a workout name to its Decl node                */
/* Stored in the interpreter so 'load' can find the right days.       */
/* ------------------------------------------------------------------ */

#define INTERP_MAX_WORKOUTS 64
#define INTERP_MAX_FUNCS    64

typedef struct {
    char  name[256];
    Decl *decl;        /* points at the DECL_WORKOUT node in the AST  */
} WorkoutEntry;

typedef struct {
    char  name[256];
    Decl *decl;        /* points at the DECL_FUNC node in the AST     */
} FuncEntry;

/* ------------------------------------------------------------------ */
/* Interpreter                                                         */
/* ------------------------------------------------------------------ */

typedef struct {
    SymbolTable   st;

    /* Flat tables for fast lookup by name at runtime. */
    WorkoutEntry  workouts[INTERP_MAX_WORKOUTS];
    int           workout_count;
    FuncEntry     funcs[INTERP_MAX_FUNCS];
    int           func_count;

    int           error_count;   /* incremented on each runtime error  */
} Interpreter;

/* ------------------------------------------------------------------ */
/* API                                                                 */
/* ------------------------------------------------------------------ */

/*
 * interp_init — initialise the interpreter and register all global
 * declarations.  Must be called before interp_run().
 */
void interp_init(Interpreter *interp, Program *prog);

/*
 * interp_run — execute the program.
 * Walks every top-level Decl; for DECL_ROUTINE, executes the body.
 * DECL_FUNC and DECL_WORKOUT are skipped at top level (they execute
 * only when called or loaded).
 * Returns 1 on success, 0 if any runtime error occurred.
 */
int interp_run(Interpreter *interp, Program *prog);

/*
 * interp_free — clean up.  Pops all open scope frames.
 */
void interp_free(Interpreter *interp);

#endif /* INTERPRETER_H */
